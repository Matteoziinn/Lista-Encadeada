package com.aula.classe;

public class Main {
    public static void main(String[] args) {
        // 1 - Contar ocorrências
        Lista lista = new Lista();
        lista.inserir(5);
        lista.inserir(3);
        lista.inserir(5);
        lista.inserir(7);
        System.out.println("Ocorrências de 5: " + lista.contarOcorrencias(5));

        // 4 - Remover pares
        lista.removerPares();
        System.out.println("Lista sem pares:");
        lista.exibir();

        // 6 - Inserir ordenado
        lista = new Lista();
        lista.inserirOrdenado(8);
        lista.inserirOrdenado(3);
        lista.inserirOrdenado(5);
        lista.inserirOrdenado(1);
        System.out.println("Lista ordenada:");
        lista.exibir();

        // 3 - Concatenar listas
        ListaEncadeadaSimples l1 = new ListaEncadeadaSimples();
        l1.inserir(1);
        l1.inserir(2);
        ListaEncadeadaSimples l2 = new ListaEncadeadaSimples();
        l2.inserir(3);
        l2.inserir(4);
        ListaEncadeadaSimples concatenada = UtilLista.concatenar(l1, l2);
        System.out.println("Lista concatenada:");
        concatenada.exibir();

        // 9 - Dividir lista
        var partes = UtilLista.dividir(concatenada, 3);
        System.out.println("Menores que 3:");
        partes.getKey().exibir();
        System.out.println("Maiores ou iguais a 3:");
        partes.getValue().exibir();

        // 8 - Lista duplamente encadeada
        ListaDuplamenteEncadeada ld = new ListaDuplamenteEncadeada();
        ld.inserir("A");
        ld.inserir("B");
        ld.inserir("C");
        ld.percorrerDuplo();

        // 5 - Lista circular duas voltas
        ListaCircular lc = new ListaCircular();
        lc.inserir("Ana");
        lc.inserir("Bruno");
        lc.inserir("Carla");
        System.out.println("Percorrendo duas voltas na lista circular:");
        lc.percorrerDuasVoltas();

        // 10 - Batata quente
        lc.inserir("Diego");
        lc.inserir("Fernanda");
        System.out.println("Batata quente:");
        lc.batataQuente(3);
    }
}
